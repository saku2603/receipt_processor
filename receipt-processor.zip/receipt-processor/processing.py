import pytesseract
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
from pdf2image import convert_from_path
from PIL import Image
import re
from models import Receipt

# Common vendor patterns
VENDOR_PATTERNS = {
    r'walmart|walmart\.com': 'Groceries',
    r'amazon|amazon\.com': 'Shopping',
    r'con edison': 'Utilities',
    r'verizon': 'Internet'
}

def extract_text_from_image(image_path):
    if image_path.endswith('.pdf'):
        images = convert_from_path(image_path)
        text = ''
        for img in images:
            text += pytesseract.image_to_string(img)
        return text
    else:
        return pytesseract.image_to_string(Image.open(image_path))

def extract_text_from_image(image_path):
    if image_path.endswith('.pdf'):
        # Simple text extraction from PDF (no Poppler needed)
        try:
            text = ""
            with open(image_path, 'rb') as f:
                for line in f:
                    try:
                        text += line.decode('utf-8')  # Extract raw text
                    except UnicodeDecodeError:
                        continue  # Skip binary data
            return text if text else "PDF text not extractable"
        except Exception as e:
            return f"Error reading PDF: {str(e)}"
    else:
        # Existing image processing
        return pytesseract.image_to_string(Image.open(image_path))

def parse_receipt_text(text):
    # Simple regex patterns - you'll need to enhance these
    date_pattern = r'\d{2}/\d{2}/\d{4}|\d{4}-\d{2}-\d{2}'
    amount_pattern = r'\$\d+\.\d{2}|\d+\.\d{2}'
    
    date = re.search(date_pattern, text)
    amount = re.search(amount_pattern, text)
    
    # Find vendor by matching known patterns
    vendor = "Unknown"
    category = "Other"
    for pattern, cat in VENDOR_PATTERNS.items():
        if re.search(pattern, text, re.IGNORECASE):
            vendor = re.search(pattern, text, re.IGNORECASE).group()
            category = cat
            break
    
    return Receipt(
        vendor=vendor,
        date=date.group() if date else "1970-01-01",
        amount=float(amount.group().replace('$', '')) if amount else 0.0,
        category=category
    )