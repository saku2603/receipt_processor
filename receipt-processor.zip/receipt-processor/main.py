import streamlit as st
from processing import extract_text_from_image, parse_receipt_text
from database import save_receipt
from algorithms import search_receipts, sort_receipts, aggregate_receipts
import pandas as pd
import matplotlib.pyplot as plt
import os

st.title("Receipt Processor")
st.sidebar.header("Options")

# File upload
uploaded_file = st.file_uploader("Upload Receipt", type=['jpg', 'png', 'pdf', 'txt'])

if uploaded_file:
    # Save to temp file
    temp_path = f"temp.{uploaded_file.name.split('.')[-1]}"
    with open(temp_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    
    try:
        text = extract_text_from_image(temp_path)
        receipt = parse_receipt_text(text)
        save_receipt(receipt)
        st.success("Receipt processed successfully!")
    except Exception as e:
        st.error(f"Error processing receipt: {str(e)}")
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)

# Search and display
st.header("Receipt Explorer")

col1, col2 = st.columns(2)
with col1:
    search_term = st.text_input("Search term")
with col2:
    sort_by = st.selectbox("Sort by", ['date', 'amount', 'vendor'])

min_amount, max_amount = st.slider(
    "Amount range (₹)",
    0.0, 10000.0, (0.0, 10000.0)
)

receipts = search_receipts(
    keyword=search_term,
    min_amount=min_amount,
    max_amount=max_amount
)

receipts = sort_receipts(receipts, sort_by=sort_by)

if receipts:
    # Display as table
    df = pd.DataFrame([{
        'Vendor': r.vendor,
        'Date': r.date,
        'Amount': r.amount,
        'Category': r.category if r.category else 'Uncategorized'
    } for r in receipts])
    
    st.dataframe(df.style.format({'Amount': '₹{:.2f}'}))
    
    # Show statistics
    st.header("Statistics")
    stats = aggregate_receipts(receipts)
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Total Spent", f"₹{stats['total']:.2f}")
        st.metric("Average Receipt", f"₹{stats['average']:.2f}")
    with col2:
        st.metric("Minimum Amount", f"₹{stats['min']:.2f}")
        st.metric("Maximum Amount", f"₹{stats['max']:.2f}")
    
    # Visualizations
    st.header("Visualizations")
    
    try:
        # Category Pie Chart
        if df['Category'].nunique() > 1:
            fig, ax = plt.subplots()
            df.groupby('Category')['Amount'].sum().plot.pie(
                ax=ax, 
                autopct='%1.1f%%',
                startangle=90,
                wedgeprops={'linewidth': 1, 'edgecolor': 'white'}
            )
            ax.set_ylabel('')
            st.pyplot(fig)
        else:
            st.warning("Need at least 2 categories for pie chart")
        
        # Monthly Trend Line Chart
        df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
        if not df['Date'].isnull().all():
            monthly = df.dropna(subset=['Date']).set_index('Date').resample('ME')['Amount'].sum()
            if len(monthly) > 1:
                fig2, ax2 = plt.subplots()
                monthly.plot(ax=ax2, marker='o')
                ax2.set_title('Monthly Spending Trend')
                ax2.set_ylabel('Amount (₹)')
                ax2.grid(True)
                st.pyplot(fig2)
            else:
                st.warning("Need at least 2 months of data for trend analysis")
        else:
            st.warning("No valid dates found for trend analysis")
            
    except Exception as e:
        st.error(f"Visualization error: {str(e)}")
else:
    st.warning("No receipts found matching your criteria")