from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Float
import re

Base = declarative_base()

class Receipt(BaseModel):
    vendor: str
    date: str  # Will be normalized to YYYY-MM-DD
    amount: float
    category: Optional[str] = None
    
    @validator('date')
    def validate_and_normalize_date(cls, value):
        """Accepts multiple date formats but stores in YYYY-MM-DD"""
        date_patterns = [
            (r'\d{2}/\d{2}/\d{4}', '%d/%m/%Y'),   # DD/MM/YYYY
            (r'\d{2}-\d{2}-\d{4}', '%d-%m-%Y'),   # DD-MM-YYYY
            (r'\d{4}-\d{2}-\d{2}', '%Y-%m-%d'),   # YYYY-MM-DD
            (r'\d{2}/\d{2}/\d{2}', '%d/%m/%y'),   # DD/MM/YY
            (r'[A-Za-z]{3} \d{2}, \d{4}', '%b %d, %Y')  # MMM DD, YYYY
        ]
        
        for pattern, fmt in date_patterns:
            if re.fullmatch(pattern, value):
                try:
                    parsed_date = datetime.strptime(value, fmt)
                    return parsed_date.strftime('%Y-%m-%d')
                except ValueError:
                    continue
        
        raise ValueError(
            f"Date must be in one of: DD/MM/YYYY, DD-MM-YYYY, "
            f"YYYY-MM-DD, DD/MM/YY, or MMM DD, YYYY. Got: {value}"
        )
    
    @validator('amount')
    def validate_amount(cls, value):
        if value <= 0:
            raise ValueError("Amount must be positive")
        return round(value, 2)

class DBReceipt(Base):
    __tablename__ = 'receipts'
    
    id = Column(Integer, primary_key=True)
    vendor = Column(String)
    date = Column(String)  # Stores normalized YYYY-MM-DD format
    amount = Column(Float)
    category = Column(String)