from models import DBReceipt  # Add this line at the top
from database import Session
from sqlalchemy import or_, and_

def search_receipts(keyword=None, min_amount=None, max_amount=None, date_range=None):
    session = Session()
    query = session.query(DBReceipt)
    
    if keyword:
        query = query.filter(or_(
            DBReceipt.vendor.contains(keyword),
            DBReceipt.category.contains(keyword)
        ))
    
    if min_amount is not None:
        query = query.filter(DBReceipt.amount >= min_amount)
    
    if max_amount is not None:
        query = query.filter(DBReceipt.amount <= max_amount)
    
    if date_range:
        start_date, end_date = date_range
        query = query.filter(and_(
            DBReceipt.date >= start_date,
            DBReceipt.date <= end_date
        ))
    
    results = query.all()
    session.close()
    return results

def sort_receipts(receipts, sort_by='date', ascending=True):
    if sort_by == 'date':
        key = lambda x: x.date
    elif sort_by == 'amount':
        key = lambda x: x.amount
    elif sort_by == 'vendor':
        key = lambda x: x.vendor
    
    return sorted(receipts, key=key, reverse=not ascending)

def aggregate_receipts(receipts):
    if not receipts:
        return {}
    
    amounts = [r.amount for r in receipts]
    return {
        'total': sum(amounts),
        'average': sum(amounts) / len(amounts),
        'min': min(amounts),
        'max': max(amounts),
        'count': len(receipts)
    }