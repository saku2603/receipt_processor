from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, DBReceipt

# Initialize database
engine = create_engine('sqlite:///receipts.db')
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
def get_all_receipts():
    session = Session()
    receipts = session.query(DBReceipt).all()
    session.close()
    return receipts
def save_receipt(receipt_data):
    session = Session()
    receipt = DBReceipt(
        vendor=receipt_data.vendor,
        date=receipt_data.date,
        amount=receipt_data.amount,
        category=receipt_data.category
    )
    session.add(receipt)
    session.commit()
    session.close()